#include <stdio.h>

int main() {
    int floor = 1;
    char name[32];
    printf("Elevator System v2.0\n");
    printf("Current Floor: %d\n", floor);
    printf("Enter access code: ");
    scanf("%s", name);
    if(floor == 1337) {
        printf("Access Granted! Flag: DNCC{3l3v4t0r_g03s_up_t0_1337}\n");
    } else {
        printf("Floor %d is locked.\n", floor);
    }
    return 0;
}