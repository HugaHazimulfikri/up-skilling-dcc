#include <stdio.h>

int main() {
    char rahasia[] = "DNCC{f0rm4t_str1ng_l34k_m3m0ry}";
    char input[100];
    printf("Sistem Echo Aktif. Masukkan kata: ");
    scanf("%99s", input);
    printf("Kamu mengetik: ");
    printf(input);
    printf("\n");
    return 0;
}
