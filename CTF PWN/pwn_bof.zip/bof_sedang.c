#include <stdio.h>
#include <string.h>

int main() {
    int admin = 0;
    char buffer[32];
    printf("Masukkan nama: ");
    scanf("%s", buffer); // Fungsi berbahaya!
    if(admin != 0) {
        printf("Akses Admin Terbuka! Flag: DNCC{b4s1c_buff3r_0v3rfl0w_m4st3r}\n");
    } else {
        printf("Halo %s, kamu bukan admin.\n", buffer);
    }
    return 0;
}