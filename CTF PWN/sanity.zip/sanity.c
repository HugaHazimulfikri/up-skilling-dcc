#include <stdio.h>
#include <string.h>

int main() {
    char cmd[50];
    
    // Mematikan buffering agar output langsung muncul (standar soal PWN)
    setvbuf(stdout, NULL, _IONBF, 0);

    printf("--- Server Rahasia DNCC ---\n");
    printf("Ketik 'help' untuk melihat perintah.\n> ");
    
    fgets(cmd, 50, stdin);
    cmd[strcspn(cmd, "\n")] = 0; // Hapus karakter enter/newline

    if (strcmp(cmd, "help") == 0) {
        printf("Perintah yang tersedia: help, about, flag\n");
    } else if (strcmp(cmd, "flag") == 0) {
        printf("DNCC{n3tc4t_15_y0ur_b35t_fr13nd}\n");
    } else {
        printf("Perintah tidak dikenal. Akses ditutup.\n");
    }

    return 0;
}