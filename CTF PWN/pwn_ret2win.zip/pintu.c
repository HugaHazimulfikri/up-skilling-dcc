#include <stdio.h>
#include <stdlib.h>

void secret_door() {
    printf("Akses Ruang Rahasia Terbuka! Flag: DNCC{r3t2w1n_b0f_m4st3r}\n");
}

int main() {
    char buffer[32];
    printf("Masukkan nama tamu: ");
    scanf("%s", buffer);
    printf("Halo %s!\n", buffer);
    return 0;
}