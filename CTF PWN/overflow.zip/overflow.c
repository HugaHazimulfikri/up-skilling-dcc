#include <stdio.h>
#include <stdlib.h>

int main() {
    // Variabel key dan buf bersebelahan di memori
    int key = 0;
    char buf[8];

    printf("Nilai variabel 'key' saat ini: 0x%08x\n", key);
    printf("Masukkan nama kamu (maksimal 8 huruf): ");
    
    // Gunakan scanf("%s") untuk menciptakan celah overflow
    scanf("%s", buf); 

    printf("Nilai 'key' sekarang berubah menjadi: 0x%08x\n", key);

    // 0x61616161 adalah representasi hex dari "aaaa"
    if (key == 0x61616161) {
        printf("\nHebat! Kamu menimpa nilai 'key' dengan tepat!\n");
        printf("Flag: DNCC{v4r_m4n1pul4t10n}\n");
    } else if (key != 0) {
        printf("\nNilai berubah, tapi bukan 0x61616161 ('aaaa'). Coba lagi!\n");
    } else {
        printf("\nNilai 'key' belum berubah. Masukkan karakter yang lebih banyak!\n");
    }

    return 0;
}

