#include <stdio.h>
#include <stdlib.h>
#include <signal.h>

// Fungsi ini akan dipanggil jika program crash (Segmentation Fault)
void sigsegv_handler(int sig) {
    printf("\n[!] Program Crash (Segmentation Fault)!\n");
    printf("Wah, kamu berhasil menembus batas buffer! Ini flag kamu:\n");
    printf("DNCC{0v3rfl0w_succ3ss}\n");
    exit(0);
}

int main() {
    // Menangkap sinyal crash
    signal(SIGSEGV, sigsegv_handler);
    
    char buffer[16];
    printf("Program ini hanya bisa menampung 16 karakter.\n");
    printf("Masukkan input: ");
    
    // Kita gunakan scanf("%s") karena ini juga rentan overflow!
    scanf("%s", buffer); 
    
    printf("Input kamu: %s\n", buffer);
    printf("Program berjalan normal. Tidak ada flag untukmu.\n");
    return 0;
}