<?php
$user_agent = $_SERVER['HTTP_USER_AGENT'];
$username = $_POST['username'];
$password = $_POST['password'];

$sql = "INSERT INTO log_kunjungan (user, agent) VALUES ('$username', '$user_agent')";

// Flag disembunyikan di dalam komentar kode oleh admin
// Ingat ya, jangan bocorkan flag ini: DNCC{h1dd3n_sq1_1nj3ct10n_1n_h34d3rs}
?>
