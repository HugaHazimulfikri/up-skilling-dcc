<?php
// Bisakah kamu mem-bypass pengecekan ini?
$password_asli = "r4h4s14_n3g4r4_1337";
$input = $_GET['pass'];
if (strcmp($input, $password_asli) == 0) {
  echo "Akses admin! DNCC{php_strcmP_byp4ss_m4st3r}";
} else {
  echo "Akses ditolak!";
}
?>